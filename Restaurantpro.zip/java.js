<button ondblclick="myalert()">
    Show Alert Message
</button>
function myalert() {
    alert("Reservation is done");
}